# Site Fixer Plus

salom qara mana shu zipdagi kodlardan foydalanib saytni to'g'irla admin panelni o'chirm logini lazizbek paroli 12345 shuni esda tut va keyi 1- rasmdagi holatga o'zgartirish kiritamiz  yeyetkazib berish tugmasini yuq qilamiz o'rbniga stolda bo'lida turib buyurtma berishni bossa stolga yetkazish  bo'limiga kirib buyurtma berishni bossa manzilga yetkazib berish imkonini qilamiz keyin tel versiyada (+1-) bo'limi boru menyuda tel verrsiyada shular mahsulot narxini ustini qoplab qolyapti shuni to'g'irla  keyin 2- rasmdagi qizil yozuvlar chiqmasin  parolni admin o'zi istagandek qo'ysin  keyin 3- rasmdagi buyurtmalar bo'limi  cheklar bo'limi bilan bir xil bo'lib qolyapti shu  buyurtma berilganda  yetkazilmoqda bo'lib tursi yetkazilgandan so'ng admin yetkazildi tugmasini bossa bu yerda ham yetkazildi bo'lib o'zgarsin

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/b7ddb4aa-8ce4-4806-8981-2a56a55bf612).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
